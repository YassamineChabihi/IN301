#include "tabint.h"
#include "stat.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

// Fonction de balayage pour le tri à bulle
// fin doit être inférieur ou égal à T.N-1
int scan_ech_tabint (TABINT T, int fin) {
	int i;
	int echange = 0;
	for ( i=0 ; i<fin ; i++)
		 if (ech_tabint(T,i)) echange = 1;
	return echange;
}

void tri_bulle_tabint (TABINT T, int optim) {
	int fin = T.N-1;
	int echange;
	int continuer = 1;
	while ( (fin>0) && (continuer) ){
		echange = scan_ech_tabint(T,fin);
		continuer = 1;
		if ((optim) && (!echange)) continuer = 0;
		fin--;
	}
}

struct stat calcul_stat(int N, int optim) {
	TABINT T;
	int i;
	NBECH = 0;
	NBCOMP = 0;
	int K = (int)1e2;
	int A = (int)1e4;
	for (i=0 ; i<K ; i++) {
		T = gen_alea_tabint (N, A);
		tri_bulle_tabint(T, optim);
	}
	
	struct stat S;
	S.N = N;
	S.nb_moy_ech  = (double)NBECH  / (double)K;
	S.nb_moy_comp = (double)NBCOMP / (double)K;

	return S;
}


int main(int argc, char * argv[]) {

	int optim = 0;
	if (argc==2) {
		printf("TRI BULLE OPTIM\n");
		optim = 1;
		}
		else {
			 printf("TRI BULLE BASE\n");
			 optim = 0;
		 }
	struct stat S;
	
	FILE *F;
	if (optim) 	F = fopen("test_tri_bulle_optim.data","w");
		else    F = fopen("test_tri_bulle_base.data","w");
	if (F==NULL) exit(21);
	int N;
	for (N=10 ; N<=(int)1e3 ; N=N*1.2) {
		S = calcul_stat(N,optim);
		fprintf(F,"%6d %15.2lf %15.2lf\n",N,S.nb_moy_comp,S.nb_moy_ech);
		printf("    %6d %15.2lf %15.2lf\n",N,S.nb_moy_comp,S.nb_moy_ech);
	}
	fclose(F);

	exit(0);
}

